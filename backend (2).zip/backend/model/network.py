import torch
import torch.nn as nn
from torchvision.models import mobilenet_v2, MobileNet_V2_Weights

class DriverBehaviorModel(nn.Module):
    def __init__(self, num_classes=10, pretrained=True):
        super(DriverBehaviorModel, self).__init__()
        # Load pre-trained MobileNetV2
        weights = MobileNet_V2_Weights.DEFAULT if pretrained else None
        self.backbone = mobilenet_v2(weights=weights)
        
        # Replace the classifier head for our specific number of classes
        # MobileNetV2 classifier is a Sequential block where index 1 is the Linear layer
        in_features = self.backbone.classifier[1].in_features
        self.backbone.classifier = nn.Sequential(
            nn.Dropout(0.2),
            nn.Linear(in_features, num_classes)
        )

    def forward(self, x):
        return self.backbone(x)
