import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader, random_split
from network import DriverBehaviorModel
from dataset import DriverDataset, get_transforms
import os

def train_model(data_dir, num_epochs=10, batch_size=32, learning_rate=0.001):
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"Using device: {device}")

    try:
        # Load full dataset
        full_dataset = DriverDataset(data_dir, transform=get_transforms(train=True))
        classes = full_dataset.classes
        
        if len(full_dataset) == 0:
            print("Dataset is empty. Please add images to train.")
            return

        # Split into train/val
        train_size = int(0.8 * len(full_dataset))
        val_size = len(full_dataset) - train_size
        train_dataset, val_dataset = random_split(full_dataset, [train_size, val_size])
        
        # Override transform for val_dataset (hacky way, but works for simple pipelines)
        val_dataset.dataset.transform = get_transforms(train=False)

        train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True)
        val_loader = DataLoader(val_dataset, batch_size=batch_size, shuffle=False)
        print(f"Loaded {len(train_dataset)} training images and {len(val_dataset)} validation images across {len(classes)} classes: {classes}")
    except Exception as e:
        print(f"Dataset not found or error loading at {data_dir}. Error: {e}")
        return

    model = DriverBehaviorModel(num_classes=len(classes)).to(device)
    criterion = nn.CrossEntropyLoss()
    optimizer = optim.Adam(model.parameters(), lr=learning_rate)

    best_val_acc = 0.0

    for epoch in range(num_epochs):
        model.train()
        running_loss = 0.0
        for inputs, labels in train_loader:
            inputs, labels = inputs.to(device), labels.to(device)
            
            optimizer.zero_grad()
            outputs = model(inputs)
            loss = criterion(outputs, labels)
            loss.backward()
            optimizer.step()
            
            running_loss += loss.item() * inputs.size(0)
            
        epoch_loss = running_loss / len(train_dataset)
        
        # Validation
        model.eval()
        val_loss = 0.0
        corrects = 0
        with torch.no_grad():
            for inputs, labels in val_loader:
                inputs, labels = inputs.to(device), labels.to(device)
                outputs = model(inputs)
                loss = criterion(outputs, labels)
                val_loss += loss.item() * inputs.size(0)
                _, preds = torch.max(outputs, 1)
                corrects += torch.sum(preds == labels.data)
                
        val_loss = val_loss / len(val_dataset)
        val_acc = corrects.double() / len(val_dataset)
        
        print(f"Epoch {epoch+1}/{num_epochs} - Train Loss: {epoch_loss:.4f} | Val Loss: {val_loss:.4f} | Val Acc: {val_acc:.4f}")
        
        if val_acc > best_val_acc:
            best_val_acc = val_acc
            torch.save(model.state_dict(), 'best_model.pth')
            print("Saved new best model!")

if __name__ == "__main__":
    # Expects data structured like:
    # d:/samruddhi/ai_project/dataset/train/c0/ (safe driving)
    # d:/samruddhi/ai_project/dataset/train/c1/ (texting)
    target_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)), "dataset")
    train_model(target_dir)
