import torch
from torchvision import transforms
from PIL import Image
import io
import base64
import os
try:
    from .network import DriverBehaviorModel
except ImportError:
    from network import DriverBehaviorModel

# Map Kaggle State Farm classes to human-readable labels
CLASS_MAP = {
    0: "Safe Driving",
    1: "Texting (Right)",
    2: "Talking on Phone (Right)",
    3: "Texting (Left)",
    4: "Talking on Phone (Left)",
    5: "Operating the Radio",
    6: "Drinking",
    7: "Reaching Behind",
    8: "Hair and Makeup",
    9: "Talking to Passenger"
}

class DriverBehaviorInference:
    def __init__(self, model_path='best_model.pth'):
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.model = DriverBehaviorModel(num_classes=10, pretrained=False)
        
        model_full_path = os.path.join(os.path.dirname(__file__), model_path)
        
        # Load weights if they exist
        if os.path.exists(model_full_path):
            self.model.load_state_dict(torch.load(model_full_path, map_location=self.device))
            self.model.to(self.device)
            self.model.eval()
            self.is_loaded = True
            print("Loaded trained model correctly!")
        else:
            self.is_loaded = False
            print("No trained weights found. Will use mock fallback until train.py is executed.")
            
        self.transform = transforms.Compose([
            transforms.Resize((224, 224)),
            transforms.ToTensor(),
            transforms.Normalize(mean=[0.485, 0.456, 0.406], 
                                 std=[0.229, 0.224, 0.225])
        ])

    def predict_from_base64(self, b64_string):
        if not self.is_loaded:
            # Fallback for mock if model isn't trained yet
            import random
            mock_class = random.choices(range(10), weights=[0.8, 0.02, 0.02, 0.02, 0.02, 0.02, 0.02, 0.02, 0.02, 0.04])[0]
            mock_conf = random.uniform(0.7, 0.99)
            return {
                "class_idx": mock_class,
                "behavior": CLASS_MAP[mock_class],
                "confidence": round(mock_conf, 2),
                "alert": mock_class != 0,
                "is_mock": True
            }

        try:
            # Decode base64 
            if ',' in b64_string:
                b64_string = b64_string.split(',')[1]
            
            image_data = base64.b64decode(b64_string)
            image = Image.open(io.BytesIO(image_data)).convert("RGB")
            
            input_tensor = self.transform(image).unsqueeze(0).to(self.device)
            
            with torch.no_grad():
                outputs = self.model(input_tensor)
                probs = torch.nn.functional.softmax(outputs, dim=1)
                confidence, preds = torch.max(probs, 1)
                
                class_idx = preds.item()
                conf_val = confidence.item()
                
            return {
                "class_idx": class_idx,
                "behavior": CLASS_MAP[class_idx],
                "confidence": round(conf_val, 2),
                "alert": class_idx != 0,
                "is_mock": False
            }
        except Exception as e:
            print("Error passing frame to model:", e)
            return {
                "class_idx": 0,
                "behavior": "Safe Driving (Error Fallback)",
                "confidence": 0.0,
                "alert": False,
                "is_mock": True
            }
